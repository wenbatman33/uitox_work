<div id="lb-search" class="lightbox hide">
	<div class="block">
		<div class="search-block">
			<div class="search-input">
				<input type="search" name="" id="" class="lb-input-search" placeholder="請輸入商品名稱">
			</div>
			<a href="" class="icon-search"></a>	
		</div>
		<a href="#" class="suggest">搜尋建議1</a>
		<a href="#" class="suggest">搜尋建議2</a>
		<a href="#" class="suggest">搜尋建議3</a>
		<a href="#" class="suggest">搜尋建議4</a>
		<a href="#" class="suggest">搜尋建議5</a>
	</div>
</div>