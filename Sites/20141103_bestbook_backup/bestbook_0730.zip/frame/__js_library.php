<script src="../assets/js/3rd-party/modernizr.custom.js"></script>
<script src="../assets/js/jquery/jquery-1.10.2.min.js"></script>
<script src="../assets/js/jquery/jquery.tap.min.js"></script>
<script src="../assets/js/3rd-party/jquery.menu-aim.js"></script>
<script src="../assets/js/3rd-party/jquery.dlmenu.js"></script>
<script src="../assets/js/common/actions.js"></script>